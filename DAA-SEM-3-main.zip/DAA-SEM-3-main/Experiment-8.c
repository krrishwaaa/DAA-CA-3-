#include <stdio.h>

int main() {
    int m, n, p, q;
    int A[100][100], B[100][100], C[100][100];
    int i, j, k;

    // Read dimensions of Matrix A
    scanf("%d %d", &m, &n);

    // Read Matrix A
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &A[i][j]);
        }
    }

    // Read dimensions of Matrix B
    scanf("%d %d", &p, &q);

    // Check whether multiplication is possible
    if (n != p) {
        printf("Invalid input");
        return 0;
    }

    // Read Matrix B
    for (i = 0; i < p; i++) {
        for (j = 0; j < q; j++) {
            scanf("%d", &B[i][j]);
        }
    }

    // Matrix multiplication
    for (i = 0; i < m; i++) {
        for (j = 0; j < q; j++) {
        }
